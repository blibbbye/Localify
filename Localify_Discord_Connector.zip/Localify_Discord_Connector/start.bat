@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js 18+ is required. & pause & exit /b 1)

REM If Localify Connector is already running, don't start a second copy.
curl.exe --silent --max-time 1 http://127.0.0.1:4219/health >nul 2>nul
if not errorlevel 1 (
  echo Localify Discord Connector is already running on port 4219.
  start "" "http://127.0.0.1:4219/"
  exit /b 0
)

if not exist node_modules (
  echo Installing connector dependencies...
  call npm install --no-fund --no-audit
  if errorlevel 1 (
    echo Failed to install dependencies.
    pause
    exit /b 1
  )
)

node server.js
pause
