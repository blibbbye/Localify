@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js 18+ is required. & pause & exit /b 1)

echo Stopping any older Localify Discord Connector instance...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ps=Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match 'Localify_Discord_Connector[\\/](server|index)\.js' }; $ps | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }"
timeout /t 1 /nobreak >nul

if not exist node_modules (
  echo Installing connector dependencies...
  call npm install --no-fund --no-audit
  if errorlevel 1 (
    echo Failed to install dependencies.
    pause
    exit /b 1
  )
)

echo Starting Localify Discord Connector v1.4.1...
node server.js
pause
