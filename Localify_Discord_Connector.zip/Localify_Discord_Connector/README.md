# Localify Discord Connector v1.4.1

This connector publishes Localify's currently playing track to Discord Desktop as a Listening Rich Presence.

## Activity data

- Header: **Listening to Localify**
- Details: **song title**
- State: **artists, comma-separated**
- Album title: **never sent as an activity field**
- Cover: public HTTPS artwork when Localify resolves one
- Progress: live timestamps
- Member-list status: uses the artist/state field rather than album/details

### Important Discord limitation

Discord controls the wording inside a Listening activity card and normally renders the artist state with a built-in **"by"** prefix. The Rich Presence API does not provide a field to remove that prefix while keeping the activity type as Listening. The connector therefore removes album text from the payload and uses the artist as the member-list state; the visible **"by"** prefix in Discord's full Listening card is controlled by Discord itself.

## Start

1. Keep Discord Desktop open.
2. Run `start.bat`.
3. Open Localify and play music.

The new `start.bat` automatically stops older Localify connector processes first, so an old connector cannot keep publishing the previous album format on port `4219`.

The connector listens only on `127.0.0.1:4219`.
