# Localify Discord Connector v1.4.0

This connector publishes Localify's currently playing track to Discord Desktop as a Listening Rich Presence.

## Activity data

- Header: **Listening to Localify**
- Details: **song title • artists**
- State: **not used**
- Album title: **never sent to Discord**
- Cover: public HTTPS artwork when Localify resolves one
- Progress: live timestamps
- Member-list status: uses the details line

### Why the artist is not in the State field

Discord automatically renders the Rich Presence `state` field with a built-in **"by"** prefix for Listening activities. Discord's RPC payload does not provide a setting to remove or rename that word. This build therefore keeps the activity type as Listening, but puts the song and artists together in the `details` field so the visible activity is **song • artists** instead of **song / by artists**.

### Album protection

The web app sends only song title, artists, artwork, and playback timing to this connector. The connector also ignores any `album` field if a stale/older client happens to send one, so album text cannot become part of the Discord activity.

## Start

1. Keep Discord Desktop open.
2. Run `start.bat`.
3. Open Localify and play music.

The `start.bat` automatically stops older Localify connector processes first, so an old connector cannot keep publishing the previous format on port `4219`.

The connector listens only on `127.0.0.1:4219`.
