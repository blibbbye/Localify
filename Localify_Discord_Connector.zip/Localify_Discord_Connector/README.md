# Localify Discord Connector

A tiny desktop companion for Localify Rich Presence.

Setup:
1. Install Node.js 18+.
2. Create a Discord Application in the Discord Developer Portal and copy its Application ID.
3. Run `start.bat`.
4. Open `http://127.0.0.1:4219/` and paste the Application ID.
5. Keep Discord Desktop open.
6. Open Localify.

While playing, Discord uses a Listening activity with `Listening to In Localify • Album`, then the song title, `by Artist`, and start/end timestamps. If the current cover art is available as a public `http(s)` image URL, the connector also sends it as the Rich Presence large image. Local images/data URLs cannot be fetched by Discord and will fall back to the application icon.

Run manually with `npm install` then `npm start`.
