# Localify Discord Connector

Localify Discord Rich Presence companion. It connects the Localify website to Discord Desktop through local Rich Presence and formats the activity like Spotify.

### Discord display
- Profile heading: **Listening to Localify**
- Track line: **song title**
- Artist line: **by Artist**
- Progress: live elapsed / total time
- Large image: current cover URL when Discord can fetch it
- Status under the user's name: **Listening to song title**

The status-under-name behavior uses Discord's `status_display_type=2` (Details), which makes a Listening activity display the activity's `details` field in the member list.

## Start
Run `start.bat`. The default Discord Application ID is already configured as `1550620411740561568`.

Keep Discord Desktop open while Localify is running.
