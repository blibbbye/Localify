# Localify Discord Connector

This tiny local companion sends Localify's currently playing track to Discord Desktop as a Listening activity.

## What Discord shows

- Activity header: **Listening to Localify**
- Song title: the current Localify track
- Artist: **Artist**
- Cover: the current song/album cover when Localify provides a public HTTPS image URL
- Time: live playback timestamps

The Discord Application ID is already built into the connector, so users do not need to enter it.

## Start

1. Keep Discord Desktop open.
2. Run `start.bat`.
3. Open Localify and play music.

The connector listens only on `127.0.0.1:4219`. The album name is used by Localify only for choosing the cover; it is not displayed in the Discord activity.

### Cover note

Discord can fetch a cover only when Localify provides a public `http://` or `https://` image URL. Local-only `blob:`/`data:`/file URLs cannot be fetched by Discord and will fall back to the application artwork.
