const http=require("http");
const fs=require("fs");
const path=require("path");
const {WebSocketServer}=require("ws");
const {Client}=require("@nxenjs/discord-rich-presence");

const VERSION="1.3.0";
const PROTOCOL="clean-listening-v5";
const PORT=Number(process.env.PORT||4219),HOST="127.0.0.1",CONFIG=path.join(__dirname,"config.json");
const defaults={clientId:"1550620411740561568"};
const load=()=>{try{return {...defaults,...JSON.parse(fs.readFileSync(CONFIG,"utf8"))}}catch{return {...defaults}}};
const save=c=>fs.writeFileSync(CONFIG,JSON.stringify(c,null,2),"utf8");
let config=load(),rpc=null,ready=false,connecting=false,latest=null;const clients=new Set();

function status(message,ok=false){const data=JSON.stringify({kind:"status",ok,message,version:VERSION,protocol:PROTOCOL});for(const ws of clients)if(ws.readyState===1){try{ws.send(data)}catch{}}}
async function drop(){ready=false;if(rpc){try{await rpc.clearActivity()}catch{}try{await rpc.destroy()}catch{}}rpc=null}
async function connect(){
  if(ready||connecting)return ready;
  config=load();
  if(!config.clientId){status("Discord App ID is not configured.",false);return false}
  connecting=true;
  try{
    rpc=new Client();
    rpc.on("ready",async()=>{
      ready=true;connecting=false;
      // Clear any stale activity left by an older connector build before we
      // publish the new clean format.
      try{await rpc.clearActivity()}catch{}
      status(`Discord connected. Connector v${VERSION}`,true);
      if(latest?.playing)await apply(latest);
    });
    rpc.on("error",e=>{ready=false;connecting=false;status("Discord RPC error: "+(e?.message||"unknown error"),false)});
    rpc.on("disconnected",()=>{ready=false;status("Discord disconnected. Retrying…",false);setTimeout(connect,3000)});
    await rpc.login(config.clientId);return true;
  }catch(e){ready=false;connecting=false;status("Could not connect to Discord. Keep Discord Desktop open.",false);return false}
}
function cleanText(value,fallback,max=128){
  const text=String(value??"").replace(/[\u0000-\u001F\u007F]/g," ").replace(/\s+/g," ").trim();
  return (text||fallback).slice(0,max);
}
function finiteNumber(value,fallback=0){const n=Number(value);return Number.isFinite(n)?n:fallback}
function activity(p){
  const song=cleanText(p.song,"Unknown song");
  const artists=Array.isArray(p.artists)
    ? p.artists.map(x=>cleanText(x,"")).filter(Boolean)
    : cleanText(p.artist,"Unknown artist").split(",").map(x=>x.trim()).filter(Boolean);
  const artistText=cleanText(artists.join(", "),"Unknown artist");
  const duration=Math.max(0,finiteNumber(p.duration,0));
  const current=Math.min(duration||Number.MAX_SAFE_INTEGER,Math.max(0,finiteNumber(p.currentTime,0)));
  const startRaw=finiteNumber(p.start,0);
  const start=startRaw>0?Math.round(startRaw):Math.round(Date.now()-current*1000);
  const end=duration>0?Math.round(start+duration*1000):0;
  const cover=cleanText(p.coverUrl,"",2048);

  // Discord's Listening renderer automatically prefixes the `state` field
  // with "by". There is no RPC field to rename/remove that word. To give
  // Localify the requested Spotify-like layout, keep the activity type as
  // Listening but put the artists in the details line and leave `state` out.
  // This guarantees the visible activity does not say "by <artist>".
  const details=cleanText(`${song} • ${artistText}`,song);

  const out={
    type:2,
    name:"Localify",
    details,
    status_display_type:2,
    instance:false
  };
  if(/^https?:\/\//i.test(cover))out.assets={large_image:cover};
  out.timestamps=end?{start,end}:{start};
  return out;
}
async function apply(p){
  latest=p;
  if(!p?.playing){if(ready&&rpc){try{await rpc.clearActivity()}catch{}}status("Discord connected — idle.",true);return}
  if(!ready&&!(await connect()))return;
  try{
    await rpc.setActivity(activity(p));
    status("Listening to "+String(p.song||"a song").slice(0,64),true)
  }catch{ready=false;status("Discord rejected the activity update.",false)}
}
function page(){
  const ok=!!config.clientId;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Localify Discord Connector</title><style>body{margin:0;background:#090b0e;color:#f7f7f8;font:16px system-ui;min-height:100vh;display:grid;place-items:center}main{width:min(620px,calc(100% - 28px));padding:24px;background:#111419;border:1px solid #282d36;border-radius:20px;box-shadow:0 24px 80px #0006}h1{margin:0 0 8px}.muted{color:#9ca3af;line-height:1.5}.status{margin:18px 0;padding:12px 14px;border-radius:12px;background:#171b21;border:1px solid #2a313a}.ok{border-color:#256d3b;background:#102016}.bad{border-color:#6d2934;background:#211015}label{display:block;font-size:12px;color:#9ca3af;font-weight:800;text-transform:uppercase;letter-spacing:.08em;margin:14px 0 7px}input{width:100%;box-sizing:border-box;background:#0c0f13;color:#fff;border:1px solid #2a3038;border-radius:11px;padding:12px}button{margin-top:14px;background:#7dd3fc;color:#081018;border:0;border-radius:11px;padding:12px 16px;font-weight:900;cursor:pointer}code{background:#151a20;border:1px solid #252b33;border-radius:6px;padding:2px 5px}</style></head><body><main><h1>Localify × Discord</h1><div class="muted">Clean Listening Rich Presence connector v${VERSION}. Album names are never sent as activity text.</div><div class="status ${ok?"ok":"bad"}">${ok?`✓ Configured automatically. Connector v${VERSION}.`:`⚠ Connector is not configured.`}</div><form method="POST" action="/config"><label>Discord Application ID</label><input name="clientId" value="${String(config.clientId||"").replace(/"/g,"&quot;")}" placeholder="1550620411740561568"><button type="submit">Save and connect</button></form><p class="muted">Keep Discord Desktop open. The connector listens only on <code>127.0.0.1:${PORT}</code>.</p></main></body></html>`;
}
const server=http.createServer((req,res)=>{
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET,POST,OPTIONS"});return res.end()}
  if(req.url==="/"||req.url==="/setup"){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});return res.end(page())}
  if(req.method==="GET"&&req.url==="/health"){res.writeHead(200,{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"});return res.end(JSON.stringify({ok:true,configured:!!config.clientId,discordConnected:ready,port:PORT,version:VERSION,protocol:PROTOCOL}))}
  if(req.method==="POST"&&req.url==="/config"){let body="";req.setEncoding("utf8");req.on("data",c=>body+=c);req.on("end",async()=>{const q=new URLSearchParams(body);config.clientId=String(q.get("clientId")||"").trim();save(config);await drop();await connect();res.writeHead(302,{Location:"/"});res.end()});return}
  res.writeHead(404);res.end("Not found")
});
const wss=new WebSocketServer({server,path:"/presence"});
wss.on("connection",ws=>{
  clients.add(ws);
  ws.send(JSON.stringify({kind:"status",ok:ready,message:ready?`Discord connected. Connector v${VERSION}.`:(config.clientId?`Connector v${VERSION} running; waiting for Discord.`:`Connector v${VERSION} is ready.`),version:VERSION,protocol:PROTOCOL}));
  ws.on("message",async raw=>{
    try{
      if(raw.length>64*1024)throw new Error("payload too large");
      const p=JSON.parse(raw.toString());
      if(!p||typeof p!=="object")throw new Error("invalid payload");
      if(p.kind==="hello")await connect();
      else if(p.kind==="presence"){
        if(typeof p.song!=="string")throw new Error("missing song");
        latest={
          playing:p.playing!==false,
          song:cleanText(p.song,"Unknown song"),
          artist:cleanText(p.artist,"Unknown artist"),
          artists:Array.isArray(p.artists)
            ? p.artists.map(x=>cleanText(x,"")).filter(Boolean)
            : cleanText(p.artist,"Unknown artist").split(",").map(x=>x.trim()).filter(Boolean),
          // Album data is intentionally ignored even if a client sends it.
          coverUrl:cleanText(p.coverUrl,"",2048),
          currentTime:finiteNumber(p.currentTime,0),
          duration:Math.max(0,finiteNumber(p.duration,0)),
          start:finiteNumber(p.start,0),
          end:finiteNumber(p.end,0)
        };
        await apply(latest);
      }else if(p.kind==="clear"){
        latest=null;if(ready&&rpc){try{await rpc.clearActivity()}catch{}}status("Discord connected — idle.",true);
      }
    }catch(e){status("Ignored invalid Localify presence payload.",false)}
  });
  ws.on("close",()=>clients.delete(ws));
  ws.on("error",()=>clients.delete(ws));
});
server.on("error",err=>{
  if(err?.code==="EADDRINUSE"){
    console.error(`Localify Discord Connector is already running at http://${HOST}:${PORT}/`);
    console.error("The new start.bat will stop older Localify connector processes automatically.");
    process.exitCode=0;
    return;
  }
  console.error(err);process.exitCode=1;
});
server.listen(PORT,HOST,async()=>{console.log(`Localify Discord Connector v${VERSION}: http://${HOST}:${PORT}/`);if(!config.clientId)console.log("No Discord Application ID configured yet.");else await connect()});
