const http=require("http");
const fs=require("fs");
const path=require("path");
const {WebSocketServer}=require("ws");
const {Client}=require("@nxenjs/discord-rich-presence");

const PORT=Number(process.env.PORT||4219),HOST="127.0.0.1",CONFIG=path.join(__dirname,"config.json");
const defaults={clientId:"",detailsPrefix:"In Localify"};
const load=()=>{try{return {...defaults,...JSON.parse(fs.readFileSync(CONFIG,"utf8"))}}catch{return {...defaults}}};
const save=c=>fs.writeFileSync(CONFIG,JSON.stringify(c,null,2),"utf8");
let config=load(),rpc=null,ready=false,connecting=false,latest=null;const clients=new Set();

function status(message,ok=false){const data=JSON.stringify({kind:"status",ok,message});for(const ws of clients)if(ws.readyState===1){try{ws.send(data)}catch{}}}
async function drop(){ready=false;if(rpc){try{await rpc.destroy()}catch{}}rpc=null}
async function connect(){
  if(ready||connecting)return ready;config=load();
  if(!config.clientId){status("Discord App ID is not configured.",false);return false}
  connecting=true;
  try{
    rpc=new Client();
    rpc.on("ready",async()=>{ready=true;connecting=false;status("Discord connected.",true);if(latest?.playing)await apply(latest)});
    rpc.on("error",e=>{ready=false;connecting=false;status("Discord RPC error: "+(e?.message||"unknown error"),false)});
    rpc.on("disconnected",()=>{ready=false;status("Discord disconnected. Retrying…",false);setTimeout(connect,3000)});
    await rpc.login(config.clientId);return true;
  }catch{ready=false;connecting=false;status("Could not connect to Discord. Keep Discord Desktop open.",false);return false}
}
function activity(p){
  const song=String(p.song||"Unknown song").slice(0,128);
  const artist=String(p.artist||"Unknown artist").slice(0,128);
  const album=String(p.album||"").slice(0,128);
  const duration=Number(p.duration||0);
  const current=Math.max(0,Number(p.currentTime||0));
  const start=Number(p.start)||Math.round(Date.now()-current*1000);
  const end=duration>0?(Number(p.end)||Math.round(start+duration*1000)):undefined;
  const appLine=(album?`${config.detailsPrefix} • ${album}`:config.detailsPrefix).slice(0,128);
  const cover=String(p.coverUrl||"");
  const assets=/^https?:\/\//i.test(cover)?{large_image:cover,large_text:(album?`${album} • ${artist}`:artist).slice(0,128)}:undefined;
  return {
    type:2,
    name:appLine,
    details:song,
    state:`by ${artist}`.slice(0,128),
    timestamps:end?{start,end}:{start},
    assets,
    instance:false
  };
}
async function apply(p){
  latest=p;
  if(!p?.playing){if(ready&&rpc){try{await rpc.clearActivity()}catch{}}status("Discord connected — idle.",true);return}
  if(!ready&&!(await connect()))return;
  try{await rpc.setActivity(activity(p));status("Listening to "+String(p.song||"a song").slice(0,64),true)}
  catch{ready=false;status("Discord rejected the activity update.",false)}
}
function page(){
  const ok=!!config.clientId;
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Localify Discord Connector</title><style>body{margin:0;background:#090b0e;color:#f7f7f8;font:16px system-ui;min-height:100vh;display:grid;place-items:center}main{width:min(620px,calc(100% - 28px));padding:24px;background:#111419;border:1px solid #282d36;border-radius:20px;box-shadow:0 24px 80px #0006}h1{margin:0 0 8px}.muted{color:#9ca3af;line-height:1.5}.status{margin:18px 0;padding:12px 14px;border-radius:12px;background:#171b21;border:1px solid #2a313a}.ok{border-color:#256d3b;background:#102016}.bad{border-color:#6d2934;background:#211015}label{display:block;font-size:12px;color:#9ca3af;font-weight:800;text-transform:uppercase;letter-spacing:.08em;margin:14px 0 7px}input{width:100%;box-sizing:border-box;background:#0c0f13;color:#fff;border:1px solid #2a3038;border-radius:11px;padding:12px}button{margin-top:14px;background:#7dd3fc;color:#081018;border:0;border-radius:11px;padding:12px 16px;font-weight:900;cursor:pointer}code{background:#151a20;border:1px solid #252b33;border-radius:6px;padding:2px 5px}</style></head><body><main><h1>Localify × Discord</h1><div class="muted">Localify sends the song currently playing to this connector, which then talks to Discord Desktop over local RPC.</div><div class="status ${ok?"ok":"bad"}">${ok?"✓ Discord App ID is configured.":"⚠ No Discord App ID is configured yet."}</div><form method="POST" action="/config"><label>Discord Application ID</label><input name="clientId" value="${String(config.clientId||"").replace(/"/g,"&quot;")}" placeholder="123456789012345678"><label>Details prefix</label><input name="detailsPrefix" value="${String(config.detailsPrefix||"In Localify").replace(/"/g,"&quot;")}" placeholder="In Localify"><button type="submit">Save and connect</button></form><p class="muted">Keep Discord Desktop open. The connector listens only on <code>127.0.0.1:${PORT}</code>.</p></main></body></html>`;
}
const server=http.createServer((req,res)=>{
  if(req.method==="OPTIONS"){res.writeHead(204,{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET,POST,OPTIONS"});return res.end()}
  if(req.url==="/"||req.url==="/setup"){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});return res.end(page())}
  if(req.method==="GET"&&req.url==="/health"){res.writeHead(200,{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"});return res.end(JSON.stringify({ok:true,configured:!!config.clientId,discordConnected:ready,port:PORT}))}
  if(req.method==="POST"&&req.url==="/config"){let body="";req.setEncoding("utf8");req.on("data",c=>body+=c);req.on("end",async()=>{const q=new URLSearchParams(body);config.clientId=String(q.get("clientId")||"").trim();config.detailsPrefix=String(q.get("detailsPrefix")||"In Localify").trim()||"In Localify";save(config);await drop();await connect();res.writeHead(302,{Location:"/"});res.end()});return}
  res.writeHead(404);res.end("Not found")
});
const wss=new WebSocketServer({server,path:"/presence"});
wss.on("connection",ws=>{clients.add(ws);ws.send(JSON.stringify({kind:"status",ok:ready,message:ready?"Discord connected.":(config.clientId?"Connector running; waiting for Discord.":"Open connector setup and enter your Discord Application ID.")}));ws.on("message",async raw=>{try{const p=JSON.parse(raw.toString());if(p.kind==="hello")await connect();else if(p.kind==="presence"){latest=p;await apply(p)}else if(p.kind==="clear"){latest=null;if(ready&&rpc){try{await rpc.clearActivity()}catch{}}status("Discord connected — idle.",true)}}catch{}});ws.on("close",()=>clients.delete(ws));ws.on("error",()=>clients.delete(ws))});
server.listen(PORT,HOST,async()=>{console.log(`Localify Discord Connector: http://${HOST}:${PORT}/`);if(!config.clientId)console.log("No Discord Application ID configured yet.");else await connect()});
